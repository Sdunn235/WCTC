## Environment

- Plugin: GitHub Copilot for Visual Studio Code 1.344.0
- Editor: Visual Studio Code 1.102.1
- Operating System: Windows_NT 10.0.19045 (x64)

## Copilot

- Version: 1.344.0
- GitHub Account: Sdunn235
- Session ID: 4663cc00-f98c-4bd0-829f-593b2020f2881753059810371
- Send Restricted Telemetry: enabled
- Content Exclusion: unavailable

## Network Configuration

- Proxy: N/A
- Proxy Authorization: N/A
- Proxy Kerberos SPN: N/A
- Proxy Strict SSL: enabled
- Fetcher: Helix
- Number of Root Certificates: 150
- TLS Default Min Version: TLSv1.2
- TLS Default Max Version: TLSv1.3

## Reachability

- github.com: HTTP 200
- api.github.com: HTTP 200
- proxy.individual.githubcopilot.com: HTTP 200
- api.individual.githubcopilot.com: HTTP 200
- telemetry.individual.githubcopilot.com: HTTP 200
