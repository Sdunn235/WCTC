

// While loops are the GOAT`!
// - you can do everything with while loop

// declare a variable   let someVar;
// assign a value to a variable someVar = 'hello'
// initialization is declaring a variable and then assigning a value to it
//      let someVar = 'hello'

// initialization statement
// -sets up a counter value for us to use
//      - incrementor, indexer, iterator
let i = 0; //in programming we start counting a 0

while (i < 5) // test expression (if true we continue the loop)
{
    console.log(i);

    // update statement
    // -increment the counter value from the initialization statement
    // i = i + 1
    // i += 1; //compound assignment operators
    i++; //increment operator
}