function buttonClick() {
    let valueOne = document.getElementById("value1");
    let valueTwo = document.getElementById("value2");

    document.getElementById("result").value = valueOne + valueTwo;
}