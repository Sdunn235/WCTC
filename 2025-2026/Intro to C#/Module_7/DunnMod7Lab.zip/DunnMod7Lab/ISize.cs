namespace DunnMod7Lab;

interface ISize
{
    public string Size { get; set; }

    public string GetSize();
}