namespace DunnMod6Lab

{
    class Pokemon
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public List<string> Moves { get; set; }
    }
    





}