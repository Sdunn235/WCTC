﻿// Shawn Dunn
// Module 1 Lab
// Due: 8/22

// Type Conversion
//  -transferring data from one type to the other
//  -Convert class
//  -Explicit Conversion 
//      -Us telling the program to convert (Convert class)
//      -This happens when we could lose data or error
//  -Implicit Conversion
//      -Happens Automatically
//      -This happens when there is no loss of data


// P.E.M.D.A.S. (Order of Operations)
//  -Parentheses
//  -Exponents
//  -Multiply or Divide
//  -Add or Subtract

Console.Write("Input first number: ");
string firstInput = Console.ReadLine();
int convertedFirstInput = Convert.ToInt32(firstInput);

Console.Write("Input second number: ");
int convertedSecondInput = Convert.ToInt32(Console.ReadLine());

Console.WriteLine(convertedFirstInput + " + " + convertedSecondInput + " = " + (convertedFirstInput + convertedSecondInput));

Console.WriteLine($"{convertedFirstInput} - {convertedSecondInput} = {convertedFirstInput - convertedSecondInput}");

Console.WriteLine($"{convertedFirstInput} * {convertedSecondInput} = {convertedFirstInput * convertedSecondInput}");

Console.WriteLine($"{convertedFirstInput} / {convertedSecondInput} = {convertedFirstInput / convertedSecondInput}");

// Concatenation Operator (ie +)
//  -combines two strings together

// Arithmetic Operator
// -Works on numbers
// + addition operator
// - subtraction operator
// * multiplication operator
// / division operator
// % modulus (remainder)
// ++ increment (adds 1)
// -- decrement (subtracts 1)

// When you do arithmetic, the result will be the biggest datatype used
// ie 
//  int + int  = interface
//  int + dbl = dbl


Console.Write("Input Width: ");
int width = Convert.ToInt32(Console.ReadLine());

// A statement is a line of code 
// An expression is anything that resolves to a single value

Console.Write("Input Height: ");
int height = Convert.ToInt32(Console.ReadLine());

Console.WriteLine($"Area: {width * height}");


// A const (constant) can not be reassigned. 

// reassigning is giving a new value to an existing variable

const double EGGS = .5;
const double CREAM_CHEESE = .375;
const double VANILLA = .125;
const double SUGAR = .125;

Console.WriteLine("How many cupcakes would you like to make?: ");
int numberOfCupCakes = Convert.ToInt32(Console.ReadLine());

Console.WriteLine($"This is the recipe for {numberOfCupCakes} cupcakes");
Console.WriteLine($"\t{numberOfCupCakes * EGGS} egg(s).");
Console.WriteLine($"\t{numberOfCupCakes * SUGAR} cup(s) of sugar.");
Console.WriteLine($"\t{numberOfCupCakes * VANILLA} tbsp(s) of vanilla.");
Console.WriteLine($"\t{numberOfCupCakes * CREAM_CHEESE} package(s) of cream cheese.");




